﻿using UnityEngine;
using System;
using System.Collections;

public class CrossbarGridDataHandler : MonoBehaviour {

  /// <summary>
  /// Struct for holding two hands.
  /// </summary>
  private struct HandsForDisplacementShader {
    private HandModel hand1;
    private HandModel hand2;

    /// <summary>
    /// Define array style access of hands from the struct.
    /// </summary>
    public HandModel this[int i] {
      get {
        switch (i) {
          case 0:
            return hand1;
          case 1:
            return hand2;
          default:
            throw new System.IndexOutOfRangeException("Hands for shader only allows 2 hands.");
        }
      }

      set {
        switch (i) {
          case 0:
            hand1 = value;
            break;
          case 1:
            hand2 = value;
            break;
          default:
            throw new System.IndexOutOfRangeException("Hands for shader only allows 2 hands.");
        }
      }
    }
  }

  /// <summary>
  /// Point in space to send to shader when hand is not availible.
  /// </summary>
  /// <remarks>
  /// We do this rather than put branching into the shader.
  /// If not availible, world origin will be used.
  /// </remarks>
  public Transform NoHandFailsafePoint_AutoDetected;
  /// <summary>
  /// Leap Motion Hand Controlller used to access hand data.
  /// </summary>
  public HandController HandController_AutoDetected;
  // Use this for initialization
  void Start() {
    // If no hand controller is provided, attempt to find a hand controller in the scene
    if (HandController_AutoDetected == null) {
      GameObject handControllerObject = GameObject.Find("HandController");
      if (handControllerObject != null) {
        HandController_AutoDetected = handControllerObject.GetComponent<HandController>();
      }
    }

    // If no failsafe point is provided, attempt to find one in the child heierarchy. 
    if (NoHandFailsafePoint_AutoDetected == null) {
      NoHandFailsafePoint_AutoDetected = transform.FindChild("NoHandFailsafePoint");
    }
  }

  /// <summary>
  /// Update shader with current hand positions.
  /// </summary>
  void Update() {
    if (HandController_AutoDetected == null) {
      return;
    }

    HandModel[] hands = HandController_AutoDetected.GetAllGraphicsHands();
    HandsForDisplacementShader shaderHands = new HandsForDisplacementShader();

    if (hands.Length > 0) {
      shaderHands[0] = hands[0];
      if (hands.Length > 1) {
        shaderHands[1] = hands[1];
      }
    }

    UpdateHandPositions(shaderHands);
  }

  /// <summary>
  /// Update shader with given hand positions or failsafe positions if no hand is provided.
  /// </summary> 
  private void UpdateHandPositions(HandsForDisplacementShader hands) {
    Vector3 failsafePosition = NoHandFailsafePoint_AutoDetected == null ? new Vector3(0, 0, 0) : NoHandFailsafePoint_AutoDetected.position;

    for (int i = 0; i < 10; i++) {
      int fingerIndex = i % 5;
      int handIndex = (int)Mathf.Floor(i / 5);
      Vector3 handPosition = hands[handIndex] != null ? hands[handIndex].fingers[fingerIndex].GetTipPosition() : failsafePosition;
      GetComponent<Renderer>().material.SetVector("_Finger" + i, handPosition);
    }
  }
}